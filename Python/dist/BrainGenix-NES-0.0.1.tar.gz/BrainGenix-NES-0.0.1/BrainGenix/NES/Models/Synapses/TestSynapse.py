# BrainGenix-NES
# AGPLv3


class TestSynapse:

    def __init__(self):

        pass