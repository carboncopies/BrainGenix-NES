# BrainGenix-NES
# AGPLv3

Remote = "Remote"