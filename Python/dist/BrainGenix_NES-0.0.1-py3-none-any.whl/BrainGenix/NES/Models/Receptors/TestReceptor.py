# BrainGenix-NES
# AGPLv3

class TestReceptor:

    def __init__(self):

        pass