# BrainGenix-NES
# AGPLv3

class TestCompartment:

    def __init__(self):

        pass